<?php

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * Seed the application's database.
     */
    public function run(): void
    {
        // User::factory(10)->create();

        // User::factory()->create([
        //     'name' => 'Test User',
        //     'email' => 'test@example.com',
        // ]);

$this->call([
              HospitalSeeder::class,
              DepartementSeeder::class,
              TypeServiceSeeder::class,
              ServiceSeeder::class,
              AddSoinsInfirmiersTypeService::class,
              AddSoinsInfirmiersServices::class,
              AddConsultationsMedicalsServices::class,
              PersonnelSeeder::class,
              PartenaireHeaderSeeder::class,
              PatientSeeder::class,
              ProductItemSeeder::class,
              TarificationSeeder::class,
              RolePermissionSeeder::class,
              UserSeeder::class,
              WebAboutSeeder::class,
              MatMedSeeder::class,
          ]);
    }
}
